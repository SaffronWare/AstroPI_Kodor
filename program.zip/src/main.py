from picamzero import Camera

cam = Camera()

cam.take_photo("image1.jpg")